__author__ = 'jeff'


from distutils.core import setup

setup(name='iPlanetLog', version='1.0', py_modules=['iPlanetLog'], author='Jeffery Smith', author_email='jeff@allthingsdork.com', url='www.allthingsdork.com',)

